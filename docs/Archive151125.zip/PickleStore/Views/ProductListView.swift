import SwiftUI


struct ProductListView: View {
    @ObservedObject var viewModel: ProductListViewModel

    var body: some View {
        NavigationView {
            List(viewModel.products) { product in
                NavigationLink(destination: OrderFormView(product: product)) {
                    HStack(spacing: 15) {
                        // Product image
                        Image(product.imageName)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 80, height: 80)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                            )
                        
                        VStack(alignment: .leading, spacing: 5) {
                            Text(product.name)
                                .font(.headline)
                            Text("Price: $\(product.price, specifier: "%.2f")")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            HStack {
                                Image(systemName: "star.fill")
                                    .foregroundColor(.yellow)
                                    .font(.caption)
                                Text("\(product.rating, specifier: "%.1f")")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Text("Delivery: $\(product.deliveryCharges, specifier: "%.2f")")
                                .font(.caption)
                                .foregroundColor(.green)
                        }
                    }
                    .padding(.vertical, 5)
                }
            }
            .navigationTitle("Pickles")
        }
    }
}
