//
//  RegisterView.swift
//  PickleStore
//
//  Created by V Akula on 13/11/2025.
//


import SwiftUI

struct RegisterView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var email = ""
    @State private var password = ""

    var body: some View {
        VStack {
            Text("Register")
                .font(.headline)
            TextField("Email", text: $email)
                .autocapitalization(.none)
                .textInputAutocapitalization(.never)
                .keyboardType(.emailAddress)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            Button("Register") {
                authViewModel.register(email: email, password: password)
            }
            .padding()
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}