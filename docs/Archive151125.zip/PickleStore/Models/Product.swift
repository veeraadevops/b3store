import Foundation

import Foundation

struct Product: Identifiable {
    let id: UUID
    let name: String
    let description: String
    let price: Double
    let rating: Double
    let weight: Double // in kilograms
    let imageName: String // Image name in Assets
    
    // Computed property for delivery charges based on weight
    var deliveryCharges: Double {
        if weight >= 10.0 {
            return 0.0 // Free delivery for 10kg+
        } else if weight >= 4.0 {
            return 8.0
        } else if weight >= 2.0 {
            return 7.0
        } else if weight >= 1.0 {
            return 6.0
        } else {
            return 4.0
        }
    }
    
    // Calculate total for quantity
    func calculateTotal(quantity: Int) -> Double {
        let totalWeight = weight * Double(quantity)
        let deliveryCharge: Double
        
        if totalWeight >= 10.0 {
            deliveryCharge = 0.0
        } else if totalWeight >= 4.0 {
            deliveryCharge = 8.0
        } else if totalWeight >= 2.0 {
            deliveryCharge = 7.0
        } else if totalWeight >= 1.0 {
            deliveryCharge = 6.0
        } else {
            deliveryCharge = 4.0
        }
        
        return (price * Double(quantity)) + deliveryCharge
    }
}
