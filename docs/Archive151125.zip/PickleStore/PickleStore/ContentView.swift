//
//  ContentView.swift
//  PickleStore
//
//  Created by V Akula on 13/11/2025.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var authViewModel = AuthViewModel()

    var body: some View {
        VStack {
            if authViewModel.isLoggedIn {
                VStack {
                    ProductListView(viewModel: ProductListViewModel())
                    Button("Logout") {
                        authViewModel.logout()
                    }
                }
            } else {
                LoginView()
                Divider().padding()
                RegisterView()
            }
            if !authViewModel.errorMessage.isEmpty {
                Text(authViewModel.errorMessage)
                    .foregroundColor(.red)
            }
        }
        .environmentObject(authViewModel)
        .padding()
    }
}

#Preview {
    ContentView()
}
