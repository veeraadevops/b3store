import Foundation
import Combine

class ProductListViewModel: ObservableObject {
    @Published var products: [Product] = [
        Product(
            id: UUID(),
            name: "Classic Pickle",
            description: "Traditional Indian pickle with a perfect blend of spices",
            price: 5.99,
            rating: 4.8,
            weight: 0.5,
            imageName: "classic-pickle"
        ),
        Product(
            id: UUID(),
            name: "Spicy Pickle",
            description: "Extra hot pickle for those who love intense flavors",
            price: 6.49,
            rating: 4.6,
            weight: 0.5,
            imageName: "spicy-pickle"
        ),
        Product(
            id: UUID(),
            name: "Sweet Pickle",
            description: "A delightful sweet and tangy pickle",
            price: 5.49,
            rating: 4.7,
            weight: 0.5,
            imageName: "sweet-pickle"
        )
    ]
    
    @Published var searchText = ""
    
    var filteredProducts: [Product] {
        if searchText.isEmpty {
            return products
        } else {
            return products.filter { product in
                product.name.localizedCaseInsensitiveContains(searchText) ||
                product.description.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
}
